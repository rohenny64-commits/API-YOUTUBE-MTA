# API YouTube MTA
API para reproducir videos/audio de YouTube en MTA SA usando HTML.

## Endpoint
/play?url=YOUTUBE_LINK

## Ejemplo
https://TU-PROYECTO.up.railway.app/play?url=https://www.youtube.com/watch?v=dQw4w9WgXcQ
